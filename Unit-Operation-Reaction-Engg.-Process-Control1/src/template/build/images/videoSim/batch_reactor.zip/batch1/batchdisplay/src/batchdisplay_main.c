/*
 * MATLAB Compiler: 4.11 (R2009b)
 * Date: Fri Sep 17 01:01:44 2004
 * Arguments: "-B" "macro_default" "-o" "batchdisplay" "-W"
 * "WinMain:batchdisplay" "-d" "C:\Documents and Settings\CHEM\My
 * Documents\MATLAB\batch1\batchdisplay\src" "-T" "link:exe" "-v" "C:\Documents
 * and Settings\CHEM\My Documents\MATLAB\MATLAB Files sent by
 * rajyam\7-batchkinetics\7-batchkinetics\displyResult_batchKinetics.m" 
 */
#include <stdio.h>
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

extern mclComponentData __MCC_batchdisplay_component_data;

#ifdef __cplusplus
}
#endif

static HMCRINSTANCE _mcr_inst = NULL;

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifndef LIB_batchdisplay_C_API
#define LIB_batchdisplay_C_API /* No special import/export declaration */
#endif

LIB_batchdisplay_C_API 
bool MW_CALL_CONV batchdisplayInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
  if (!mclInitializeComponentInstanceWithEmbeddedCTF(&_mcr_inst, 
                                                     &__MCC_batchdisplay_component_data, 
                                                     true, NoObjectType, ExeTarget, 
                                                     error_handler, print_handler, 73874, 
                                                     NULL))
    return false;
  return true;
}

LIB_batchdisplay_C_API 
bool MW_CALL_CONV batchdisplayInitialize(void)
{
  return batchdisplayInitializeWithHandlers(mclDefaultErrorHandler, 
                                            mclDefaultPrintHandler);
}
LIB_batchdisplay_C_API 
void MW_CALL_CONV batchdisplayTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

int run_main(int argc, const char **argv)
{
  int _retval;
  /* Generate and populate the path_to_component. */
  char path_to_component[(PATH_MAX*2)+1];
  separatePathName(argv[0], path_to_component, (PATH_MAX*2)+1);
  __MCC_batchdisplay_component_data.path_to_component = path_to_component; 
  if (!batchdisplayInitialize()) {
    return -1;
  }
  argc = mclSetCmdLineUserData(mclGetID(_mcr_inst), argc, argv);
  _retval = mclMain(_mcr_inst, argc, argv, "displyResult_batchKinetics", 0);
  if (_retval == 0 /* no error */) mclWaitForFiguresToDie(NULL);
  batchdisplayTerminate();
#if defined( _MSC_VER)
  PostQuitMessage(0);
#endif
  mclTerminateApplication();
  return _retval;
}

#if defined( _MSC_VER)

#define argc __argc
#define argv __argv

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
#else
int main(int argc, const char **argv)

#endif
{
  if (!mclInitializeApplication(
    __MCC_batchdisplay_component_data.runtime_options, 
    __MCC_batchdisplay_component_data.runtime_option_count))
    return 0;

  return mclRunMain(run_main, argc, argv);
}
